﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FinalProject
{
    public partial class Main : Form
    {
        public Main()
        {
            InitializeComponent();
        }

        //Payment Button 
        private void button4_Click(object sender, EventArgs e)
        {
            Payment pay = new Payment();
            pay.Show();
            this.Hide();
        }
        // Add Member Button 
        private void button1_Click(object sender, EventArgs e)
        {
            AddMember addmember = new AddMember();
            addmember.Show();
            this.Hide();
        }
        //Update and Delete Button 
        private void button2_Click(object sender, EventArgs e)
        {
           UpdateDelete Update = new UpdateDelete();
           Update.Show();
            this.Hide();
        }
        // View Member Button 
        private void button3_Click(object sender, EventArgs e)
        {
            ViewMembers viewmember = new ViewMembers();
            viewmember.Show();
            this.Hide();
        }
        // Close the Aoolication 
        private void label1_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
