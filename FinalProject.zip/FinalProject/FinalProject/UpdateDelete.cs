﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FinalProject
{
    public partial class UpdateDelete : Form
    {
        public UpdateDelete()
        {
            InitializeComponent();
        }

       // Paste from WPC.mdf
        SqlConnection Con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\comic\Downloads\FinalProject\FinalProject\WPC.mdf;Integrated Security=True");
       
        // Foarm; load
        private void populate()
        {
            Con.Open();
            string query = "select * from MemberTbl";
            SqlDataAdapter sda = new SqlDataAdapter(query, Con);
            SqlCommandBuilder builder = new SqlCommandBuilder();
            var ds = new DataSet();
            sda.Fill(ds);
            MemberSDGV.DataSource = ds.Tables[0];
            Con.Close();
        }
        // Return populate() 
        private void UpdateDelete_Load(object sender, EventArgs e)
        {
            populate();
        }

        //Table chart 

       int key = 0;
        private void MemberSDGV_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            MemberSDGV_LoadForEdit(sender, e);
        }
        private void MemberSDGV_LoadForEdit(object sender, DataGridViewCellEventArgs e)
        {
            int key_test = e.RowIndex;
          
            if (key_test > -1 && key_test < MemberSDGV.Rows.Count) { 
            key = key_test;
            NameTb.Text = MemberSDGV.Rows[key_test].Cells[1].Value.ToString();
            PhoneTb.Text = MemberSDGV.Rows[key_test].Cells[2].Value.ToString();
            GenderCb.Text = MemberSDGV.Rows[key_test].Cells[3].Value.ToString();
            AgeTb.Text = MemberSDGV.Rows[key_test].Cells[4].Value.ToString();
            AmountTb.Text = MemberSDGV.Rows[key_test].Cells[5].Value.ToString();
            TimingCB.Text = MemberSDGV.Rows[key_test].Cells[6].Value.ToString();
            }
        }
                    /* Previous Example */ 
        //key = Convert.ToInt32(MemberSDGV.SelectedRows[0].Cells[0].Value.ToString());
        //NameTb.Text = MemberSDGV.SelectedRows[0].Cells[1].Value.ToString();
        //PhoneTb.Text = MemberSDGV.SelectedRows[0].Cells[2].Value.ToString();
        //GenderCb.Text = MemberSDGV.SelectedRows[0].Cells[3].Value.ToString();
        //AgeTb.Text = MemberSDGV.SelectedRows[0].Cells[4].Value.ToString();
        //AmountTb.Text = MemberSDGV.SelectedRows[0].Cells[5].Value.ToString();
        //TimingCB.Text = MemberSDGV.SelectedRows[0].Cells[6].Value.ToString();

        //Reset text
        private void button2_Click(object sender, EventArgs e)
        {
            NameTb.Text = "";
            AgeTb.Text = "";
            PhoneTb.Text = "";
            TimingCB.Text = "";
            AmountTb.Text = "";
            GenderCb.Text = "";
        }

        //Back; return to main
        private void button4_Click(object sender, EventArgs e)
        {
            Main  main = new Main();
            main.Show();
            this.Hide();
        }
        
        // Delete info that filled 
        private void button3_Click(object sender, EventArgs e)
        {
            if(key == 0)
            {
                MessageBox.Show("Select The Member To Be Deleted");
            }
            else
            {
                try
                {
                    Con.Open();
                    string query = "delete from MemberTbl where MId=" + key + ";";
                    SqlCommand cmd = new SqlCommand(query, Con);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Member Deleted Successfully");
                    Con.Close();
                    populate();
                } catch(Exception Ex)
                {
                    MessageBox.Show(Ex.Message);
                }
            }
        }

        //Update info that filled
        private void button1_Click(object sender, EventArgs e)
        {
            if (key == 0 || NameTb.Text == "" || PhoneTb.Text == "" || AgeTb.Text == "" || AmountTb.Text == "" || GenderCb.Text == "" || TimingCB.Text == "")
            {
                MessageBox.Show("Missing Information");
            }
            else
            {
                try
                {
                    Con.Open();
                    string query = "update MemberTbl set MName='" + NameTb.Text + "', MPhone='" + PhoneTb.Text + "',MGen='" + GenderCb.Text + "',MAge=" + AgeTb.Text + ",MAmount=" + AmountTb.Text + ",MTiming='" + TimingCB.Text + "' where MId="+key+";";

                    SqlCommand cmd = new SqlCommand(query, Con);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Member Updated Successfully");
                    Con.Close();
                    populate();
                }
                catch (Exception Ex)
                {
                    MessageBox.Show(Ex.Message);
                }
            }
        }
        
        // Close the form 
        private void label3_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        // Double click cells 
        private void MemberSDGV_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            MemberSDGV_LoadForEdit(sender, e);
        }

        private void MemberSDGV_CellContentDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            MemberSDGV_LoadForEdit(sender, e);
        }

        private void MemberSDGV_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            MemberSDGV_LoadForEdit(sender, e);

        }

        private void MemberSDGV_CellMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        {
          

        }
    }
}
