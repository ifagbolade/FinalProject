﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FinalProject
{
    public partial class ViewMembers : Form
    {
        public ViewMembers()
        {
            InitializeComponent();
        }

        // Close the foarm 
        private void label3_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
        // Paste from WPC.mdf 
        SqlConnection Con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\comic\Downloads\FinalProject\FinalProject\WPC.mdf;Integrated Security=True");
       
        // Refresh application 
        private void populate()
        {
            Con.Open();
            string query = "select * from MemberTbl";
            SqlDataAdapter sda = new SqlDataAdapter(query, Con);
            SqlCommandBuilder builder = new SqlCommandBuilder();
            var ds = new DataSet();
            sda.Fill(ds);
            MemberSDGV.DataSource = ds.Tables[0];
            Con.Close();
        }

        // Foarm to load 
        private void ViewMembers_Load(object sender, EventArgs e)
        {
            populate();
        }

        // Back button; rturn to main 
        private void button4_Click(object sender, EventArgs e)
        {
            Main main = new Main();
            main.Show();
            this.Hide();
        }

        // Search Button; exucte 
        private void filterByName()
        {
            Con.Open();
            string query = "select * from MemberTbl where MName='" + SearchMember.Text + "'";
            SqlDataAdapter sda = new SqlDataAdapter(query, Con);
            SqlCommandBuilder builder = new SqlCommandBuilder();
            var ds = new DataSet();
            sda.Fill(ds);
            MemberSDGV.DataSource = ds.Tables[0];
            Con.Close();
        }

        // Return filterbyname 
        private void button2_Click(object sender, EventArgs e)
        {
            filterByName();
        }

        //Return Populate; refresh button 
        private void button1_Click(object sender, EventArgs e)
        {
            populate();
        }
    }
}
